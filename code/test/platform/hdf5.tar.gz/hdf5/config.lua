hdf5._config = {
    HDF5_INCLUDE_PATH = "/usr/local/Cellar/hdf5/1.8.16/include",
    HDF5_LIBRARIES = "/usr/local/lib/libhdf5.dylib;/usr/local/lib/libsz.dylib;/usr/lib/libz.dylib;/usr/lib/libdl.dylib;/usr/lib/libm.dylib"
}
